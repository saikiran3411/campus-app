package com.cg.air.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.air.dto.BookingInformation;
import com.cg.air.dto.FlightInformation;
import com.cg.air.dto.Users;
import com.cg.air.exception.AirlineException;
import com.cg.air.service.AirportServices;
import com.cg.air.service.AirportServicesImpl;
import com.cg.air.service.BookingServices;
import com.cg.air.service.BookingServicesImpl;
import com.cg.air.service.FlightServices;
import com.cg.air.service.FlightServicesImpl;
import com.cg.air.service.UserServices;
import com.cg.air.service.UserServiceImpl;


@WebServlet("*.do")
public class AirlineController extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    public AirlineController() 
    {
        super();
        
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		AirportServices service=new AirportServicesImpl();
		UserServices service1=new UserServiceImpl();
		FlightServices flightservice=new FlightServicesImpl();
		BookingServices bookservice=new BookingServicesImpl();
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String urlPattern=request.getServletPath();
		String url=request.getServletPath();
		List<String> airport=new ArrayList<String>();
		System.out.println(urlPattern);
		
	    switch(urlPattern)
	    {
	    
	    case "/jsps/register.do":
	    	
	    	response.sendRedirect("index.jsp");
	    	
	    	break;
	    	
	    case "/jsps/login.do" :
	    	
	    	response.sendRedirect("login.jsp");
	    	
	    	break;
         
	    case "/jsps/airport.do" :
	    	
	    	response.sendRedirect("airport.jsp");
	    	
	    	break;
	    	
	    case "/jsps/register1.do":
	    	System.out.println("reg");
			
				try
				{
					airport=service.getScheme();
					request.setAttribute("airport",airport);
					RequestDispatcher rd=request.getRequestDispatcher("airport.jsp");
					rd.forward(request, response);
				} 
			catch (AirlineException e) 
				{
					RequestDispatcher rd = request.getRequestDispatcher("mobileerror.jsp");
					request.setAttribute("exception",e);
					rd.forward(request, response); 
				}
			break;
	    
	    case "/jsps/addusers.do":
	    		String username=request.getParameter("userName");
	    		String password=request.getParameter("password");
	    		String role=request.getParameter("role");
	    		String mobileno=request.getParameter("mobileNo");
	    		Users user=new Users();
	    		user.setUserName(username);
	    		user.setPassword(password);
	    		user.setRole(role);
	    		user.setMobileNo(mobileno);
	    		try 
	    	    {
	    			int result=service1.adduser(user);
	    			request.getSession().setAttribute("userName", username);
	    			if(result==1)
	    			{
	    				Date date = new Date();
	    				request.getSession().setAttribute("date", date);
	    				RequestDispatcher rd = request.getRequestDispatcher("flightinformation.jsp");
	    				rd.forward(request, response);
	    			} 
	    	    }
	    		catch (SQLException e) 
	    		{
	    			request.setAttribute("exception", e);
	    			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
	    			dispatcher.forward(request, response);
	    		} 
	    		catch (AirlineException e) 
	    		{
	    			request.setAttribute("exception", e);
	    			RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
	    			dispatcher.forward(request, response);
	    		}
	    		break;
	    
	    case "/isvalid.do":
	    	try {
	    	String username1=request.getParameter("username");
	 	    String password1=request.getParameter("password");
	 	    Users user1=new Users();
	 	    user1.setUserName(username1);
		    user1.setPassword(password1);
	        
				boolean result=service1.isvalid(user1);
				if(result==true){
					RequestDispatcher dispatcher = request.getRequestDispatcher("success.jsp");
					dispatcher.forward(request, response);
				}
				else{
					RequestDispatcher dispatcher = request.getRequestDispatcher("failure.jsp");
					dispatcher.forward(request, response);
					
				}
				
			} catch (SQLException e) {
				request.setAttribute("exception", e);
				RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
				dispatcher.forward(request, response);
			} catch (AirlineException e) {
				request.setAttribute("exception", e);
				RequestDispatcher dispatcher = request.getRequestDispatcher("error.jsp");
				dispatcher.forward(request, response);
			}
	    	break;

	       case "/jsps/flightinfo.do":
        FlightInformation flight=new  FlightInformation();
		String sourcecity=request.getParameter("sourcecity");
		String destinationcity=request.getParameter("destinationcity");    	
		System.out.println("In controller scity"+ sourcecity);
		System.out.println("In controller dcity"+ destinationcity);	   
	    flight = flightservice.searchflight(sourcecity,destinationcity);   
	    request.setAttribute("flight", flight);
	    RequestDispatcher dispatcher = request.getRequestDispatcher("flightdetails.jsp");
		dispatcher.forward(request, response);
        break;
	       
	       
	       case "/jsps/payBill.do":
				int nop = Integer.parseInt(request.getParameter("noOfPassengers"));
				
				int remaining= 100-nop;
				
				String message=null;
				if(remaining>0){
					message="Remaining Seats"+remaining;
					
				}else{
					message="No balance";
				}
			request.getSession().setAttribute("message", message);	
			request.setAttribute("nop", nop);
			RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
			rd.forward(request, response);
  
	    }
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doGet(request,response);
	}

}
