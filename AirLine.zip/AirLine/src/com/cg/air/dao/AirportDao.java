package com.cg.air.dao;

import java.util.List;

import com.cg.air.dto.Airport;
import com.cg.air.exception.AirlineException;

public interface AirportDao 
{
	
	public Airport getPlan(String scheme);

	public List<String> getScheme() throws AirlineException;

}
