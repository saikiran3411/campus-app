package com.cg.air.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.air.dto.Airport;
import com.cg.air.exception.AirlineException;
import com.cg.air.util.DbUtil;

public class AirportDaoImpl implements AirportDao
{
	public List<String> getScheme() throws AirlineException
	{
		Connection con=null;
		PreparedStatement st=null;
		List<String> airport=new ArrayList<String>();

		try 
		{
			con=DbUtil.getConnection();
			st=con.prepareStatement("SELECT airportname FROM airport");
			ResultSet rs=st.executeQuery();
			while(rs.next())
				{
				airport.add(rs.getString(1));
				}
	    } 
		catch (SQLException e) 
			{
				e.printStackTrace();
			}
		System.out.println(airport.size());
		return airport;
	}

	@Override
	public Airport getPlan(String scheme) {
		// TODO Auto-generated method stub
		return null;
	}


	
}

