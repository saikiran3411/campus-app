package com.cg.air.dao;

import java.util.List;

import com.cg.air.dto.BookingInformation;
import com.cg.air.exception.AirlineException;

public interface BookingDao 
{

	public List<BookingInformation> getAllBookings() throws AirlineException;
	public List<BookingInformation> deleteBooking(int id) throws AirlineException;
	public List<BookingInformation> updateBooking(BookingInformation bookingInfo)throws AirlineException;
	public List<BookingInformation> addBooking(BookingInformation bookingInfo) throws AirlineException;

}
