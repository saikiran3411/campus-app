package com.cg.air.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.cg.air.dto.BookingInformation;
import com.cg.air.exception.AirlineException;
import com.cg.air.util.DbUtil;

public class BookingDaoImpl implements BookingDao
{


	@Override
	public List<BookingInformation> addBooking(BookingInformation bookingInfo) throws AirlineException
	{
		Connection con=DbUtil.getConnection();
		
		ResultSet rs=null;
		PreparedStatement stat=null;
		try {
			stat=con.prepareStatement("INSERT INTO BookingInformation VALUES(bookingidseq.nextval,?,?,?,?,?,?,?,?)");
			stat.setString(1,bookingInfo.getBookingId());
			stat.setString(2, bookingInfo.getCustomerEmail());
			stat.setString(3, bookingInfo.getNoOfPassengers());
			stat.setString(4, bookingInfo.getClassType());
			stat.setString(5, bookingInfo.getTotalFare());
			stat.setString(6, bookingInfo.getSeatNumbers());
			stat.setString(7, bookingInfo.getCreditCardInfo());
			stat.setString(8, bookingInfo.getSourceCity());
			stat.setString(9, bookingInfo.getDestinationCity());
			stat.executeUpdate();
			return getAllBookings();
		
		} catch (AirlineException e) {
			throw new AirlineException(e.getMessage());
		} catch (SQLException e) {
			throw new AirlineException(e.getMessage());
		}
		
	}

	@Override
	public List<BookingInformation> getAllBookings() throws AirlineException {
		List<BookingInformation> bookings=new ArrayList<BookingInformation>();
		
		Connection con=null;
		Statement stat=null;
		ResultSet rs=null;
		con=DbUtil.getConnection();
		
		try {
			stat=con.createStatement();
			rs=stat.executeQuery("SELECT * FROM BookingInformation");
			while(rs.next())
			{
				BookingInformation bookingInfo = new BookingInformation();
				bookingInfo.setBookingId(rs.getString(1));
				bookingInfo.setCustomerEmail(rs.getString(2));
				bookingInfo.setNoOfPassengers(rs.getString(3));
				bookingInfo.setClassType(rs.getString(4));
				bookingInfo.setTotalFare(rs.getString(5));
				bookingInfo.setSeatNumbers(rs.getString(6));
				bookingInfo.setCreditCardInfo(rs.getString(7));
				bookingInfo.setSourceCity(rs.getString(8));
				bookingInfo.setDestinationCity(rs.getString(9));
				bookings.add(bookingInfo);
			}
			return bookings;		
		} 
		catch (SQLException e) 
		{
			throw new AirlineException(e.getMessage());
		}
		
		finally{
			
			try {
				stat.close();
				rs.close();
				con.close();
			} catch (SQLException e) {
				throw new AirlineException(e.getMessage());
			}	
		}			
		
	}


	@Override
	public List<BookingInformation> deleteBooking(int id)
			throws AirlineException
	{
		PreparedStatement stat=null;
		Connection con=DbUtil.getConnection();
		try {
			stat=con.prepareStatement("DELETE BookingInformation WHERE ID=?");
			stat.setInt(1, id);
			stat.executeUpdate();
			return getAllBookings();
		} 
		catch (SQLException e) 
		{
			throw new AirlineException(e.getMessage());
		}	
		finally
		{
			try {
				stat.close();
				con.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}
			
		}

	}

	@Override
	public List<BookingInformation> updateBooking(BookingInformation bookingInfo)
			throws AirlineException 
	{
		PreparedStatement stat=null;
		Connection con=DbUtil.getConnection();
	
			try {
				stat=con.prepareStatement
					("UPDATE BookingInformation "
							+ "set cust_email=?,no_of_passengers=?,"
							+ "class_type=?,total_fare=?,seat_number=?,"
							+ "creditcard_info=?,src_city=?,dest_city=? "
							+ "WHERE booking_id=?");
				stat.setString(1, bookingInfo.getCustomerEmail());
				stat.setString(2, bookingInfo.getNoOfPassengers());
				stat.setString(3, bookingInfo.getClassType());
				stat.setString(4, bookingInfo.getTotalFare());
				stat.setString(5, bookingInfo.getSeatNumbers());
				stat.setString(6, bookingInfo.getCreditCardInfo());
				stat.setString(7, bookingInfo.getSourceCity());
				stat.setString(8, bookingInfo.getDestinationCity());
				stat.setString(9, bookingInfo.getBookingId());
				stat.executeUpdate();
				return getAllBookings();

			} catch (SQLException e) {
				throw new AirlineException(e.getMessage());
			}
	
	}

}
