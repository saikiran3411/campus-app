package com.cg.air.dao;

import com.cg.air.dto.FlightInformation;

public interface FlightDao 
{

	FlightInformation searchflight(String sourcecity, String destinationcity);
	

}
