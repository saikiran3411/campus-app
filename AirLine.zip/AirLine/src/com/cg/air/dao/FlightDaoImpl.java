 package com.cg.air.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import com.cg.air.dto.FlightInformation;
import com.cg.air.exception.AirlineException;
import com.cg.air.util.DbUtil;

public class FlightDaoImpl implements FlightDao {
	Statement stat;
	PreparedStatement pst;
	Connection con;
    ResultSet rs;
    
	@Override
	public FlightInformation searchflight(String sourcecity, String destinationcity) {
		
		FlightInformation flight = new FlightInformation();
		
		try {
			
			System.out.println("In Impl");
			
			con = DbUtil.getConnection();
			pst = con.prepareStatement("select * from FlightInformation where dep_city=? and arr_city=? ");
			pst.setString(1, sourcecity);
			pst.setString(2, destinationcity);
			
			rs = pst.executeQuery();
			
			rs.next();
			flight.setFlightNo(rs.getString(1));
			flight.setAirLine(rs.getString(2));
			flight.setDepartureCity(rs.getString(3));
			flight.setArrivalCity(rs.getString(4));
			flight.setDepartureDate(rs.getDate(5).toLocalDate());
			flight.setArrivalDate(rs.getDate(6).toLocalDate());
			flight.setDepartureTime(rs.getString(7));
			flight.setArrivalTime(rs.getString(8));
			flight.setFirstSeats(rs.getString(9));
			flight.setFirstSeatFare(rs.getString(10));
			flight.setBussSeats(rs.getString(11));
			flight.setBussSeatsFare(rs.getString(12));
			
			System.out.println("Impl flightno"+flight.getFlightNo());
			
			return flight;

		} catch (AirlineException e) {
		} catch (SQLException e) {
		}

		return null;
	}
    
	
}
