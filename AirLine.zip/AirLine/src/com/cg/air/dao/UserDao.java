package com.cg.air.dao;

import java.sql.SQLException;

import com.cg.air.dto.Users;
import com.cg.air.exception.AirlineException;

public interface UserDao {
	public int adduser(Users users) throws SQLException, AirlineException;
	public boolean isvalid(Users users) throws SQLException, AirlineException;
}