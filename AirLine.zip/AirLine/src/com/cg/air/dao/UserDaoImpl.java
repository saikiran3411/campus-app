package com.cg.air.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;






import com.cg.air.dto.Users;
import com.cg.air.exception.AirlineException;
import com.cg.air.util.DbUtil;

public class UserDaoImpl implements UserDao{
    Statement stat;
    PreparedStatement pst;
    Connection con;
	public int adduser(Users users) throws SQLException, AirlineException {
		try {
			con=DbUtil.getConnection();
		    pst=con.prepareStatement("INSERT into users values(?,?,?,?)");
			pst.setString(1, users.getUserName());
			pst.setString(2, users.getPassword());
			pst.setString(3, users.getRole());
			pst.setString(4, users.getMobileNo());
			 System.out.println(users.getUserName());
			 return pst.executeUpdate();
			
		} catch (AirlineException e) {
			throw new AirlineException(e.getMessage());
			
		} catch (SQLException e) {
			
			throw new AirlineException(e.getMessage());
		}
		
	}
	public boolean isvalid(Users users) throws SQLException, AirlineException {
		
		con=DbUtil.getConnection();
		 boolean isvalid = false;
		 pst=con.prepareStatement("SELECT * from users where username=? and password=?");
		 pst.setString(1, users.getUserName());
		 pst.setString(2, users.getPassword());
		 ResultSet rs=pst.executeQuery();
		 while(rs.next()){
			
			 if((users.getUserName().equalsIgnoreCase(rs.getString("username")))&&(users.getPassword().equalsIgnoreCase(rs.getString("password")))){
				
				 isvalid=true;
				 
			 }
			 
		 }
		return isvalid;
	}

}