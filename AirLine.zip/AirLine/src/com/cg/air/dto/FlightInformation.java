package com.cg.air.dto;

import java.time.LocalDate;
public class FlightInformation
{
	private String flightNo;
	private String airLine;
	private String departureCity;
	private String arrivalCity;
	private LocalDate departureDate;
	private LocalDate arrivalDate;
	private String departureTime;
	private String arrivalTime;
	private String firstSeats;
	private String firstSeatFare;
	private String bussSeats;
	private String bussSeatsFare;
	public String getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}
	public String getAirLine() {
		return airLine;
	}
	public void setAirLine(String airLine) {
		this.airLine = airLine;
	}
	public String getDepartureCity() {
		return departureCity;
	}
	public void setDepartureCity(String departureCity) {
		this.departureCity = departureCity;
	}
	public String getArrivalCity() {
		return arrivalCity;
	}
	public void setArrivalCity(String arrivalCity) {
		this.arrivalCity = arrivalCity;
	}
	public LocalDate getDepartureDate() {
		return departureDate;
	}
	public void setDepartureDate(LocalDate localDate) {
		this.departureDate = localDate;
	}
	public LocalDate getArrivalDate() {
		return arrivalDate;
	}
	public void setArrivalDate(LocalDate localDate) {
		this.arrivalDate = localDate;
	}
	public String getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(String string) {
		this.departureTime = string;
	}
	public String getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(String string) {
		this.arrivalTime = string;
	}
	public String getFirstSeats() {
		return firstSeats;
	}
	public void setFirstSeats(String firstSeats) {
		this.firstSeats = firstSeats;
	}
	public String getFirstSeatFare() {
		return firstSeatFare;
	}
	public void setFirstSeatFare(String firstSeatFare) {
		this.firstSeatFare = firstSeatFare;
	}
	public String getBussSeats() {
		return bussSeats;
	}
	public void setBussSeats(String bussSeats) {
		this.bussSeats = bussSeats;
	}
	public String getBussSeatsFare() {
		return bussSeatsFare;
	}
	public void setBussSeatsFare(String bussSeatsFare) {
		this.bussSeatsFare = bussSeatsFare;
	}
	@Override
	public String toString() {
		return "FlightInformation [flightNo=" + flightNo + ", airLine="
				+ airLine + ", departureCity=" + departureCity
				+ ", arrivalCity=" + arrivalCity + ", departureDate="
				+ departureDate + ", arrivalDate=" + arrivalDate
				+ ", departureTime=" + departureTime + ", arrivalTime="
				+ arrivalTime + ", firstSeats=" + firstSeats
				+ ", firstSeatFare=" + firstSeatFare + ", bussSeats="
				+ bussSeats + ", bussSeatsFare=" + bussSeatsFare + "]";
	}
	
	}
	