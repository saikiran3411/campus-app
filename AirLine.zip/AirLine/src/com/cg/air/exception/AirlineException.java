package com.cg.air.exception;

public class AirlineException extends Exception{
	public AirlineException()
	{
		super();
	}
	public AirlineException(String message)
	{
		super(message);
	}

}
