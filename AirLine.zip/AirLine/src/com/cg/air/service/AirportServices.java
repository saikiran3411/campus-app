package com.cg.air.service;

import java.util.List;


import com.cg.air.dto.Airport;
import com.cg.air.dto.BookingInformation;
import com.cg.air.exception.AirlineException;

public interface AirportServices 
{

	public Airport getPlan(String scheme);

	public List<String> getScheme() throws AirlineException;

	
}
