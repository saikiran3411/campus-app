package com.cg.air.service;

import java.util.List;

import com.cg.air.dao.AirportDao;
import com.cg.air.dao.AirportDaoImpl;
import com.cg.air.dto.Airport;
import com.cg.air.dto.BookingInformation;
import com.cg.air.exception.AirlineException;

public class AirportServicesImpl implements AirportServices
{
	AirportDao airportdao=new AirportDaoImpl();
	@Override
	public Airport getPlan(String scheme) {
		// TODO Auto-generated method stub
		return airportdao.getPlan(scheme);
	}

	@Override
	public List<String> getScheme() throws AirlineException {
		// TODO Auto-generated method stub
		return airportdao.getScheme();
	}

	

}
