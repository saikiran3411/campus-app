package com.cg.air.service;

import java.util.List;

import com.cg.air.dao.BookingDao;
import com.cg.air.dao.BookingDaoImpl;
import com.cg.air.dto.BookingInformation;
import com.cg.air.exception.AirlineException;

public class BookingServicesImpl implements BookingServices 
{

	BookingDao bookinginfodao = new BookingDaoImpl();

	@Override
	public List<BookingInformation> getAllBookings() throws AirlineException {
		
		return bookinginfodao.getAllBookings();
	}

	@Override
	public List<BookingInformation> deleteBooking(int id)
			throws AirlineException {
		
		return bookinginfodao.deleteBooking(id);
	}

	@Override
	public List<BookingInformation> updateBooking(BookingInformation bookingInfo)
			throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BookingInformation addBooking(BookingInformation bookingInfo)
			throws AirlineException {
		// TODO Auto-generated method stub
		return null;
	}
	
		
}
