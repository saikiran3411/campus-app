package com.cg.air.service;

import com.cg.air.dto.FlightInformation;

public interface FlightServices 
{	
	public FlightInformation searchflight(String sourcecity,String destinationcity);
}
