package com.cg.air.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;

import com.cg.air.dao.FlightDaoImpl;
import com.cg.air.dao.FlightDao;
import com.cg.air.dto.FlightInformation;

public class FlightServicesImpl implements FlightServices{
    FlightDao dao=new FlightDaoImpl();
/*	@Override
	public List<FlightInformation> searchflight(FlightInformation flight) {
		
		return dao.searchflight(flight);
	}
*/

	@Override
	public FlightInformation searchflight(String sourcecity,String destinationcity) {
		return dao.searchflight(sourcecity,destinationcity);
	}

}