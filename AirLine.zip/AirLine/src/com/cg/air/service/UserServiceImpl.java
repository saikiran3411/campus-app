package com.cg.air.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.air.dao.UserDaoImpl;
import com.cg.air.dao.UserDao;
import com.cg.air.dto.Users;
import com.cg.air.exception.AirlineException;

public class UserServiceImpl implements UserServices{
 UserDao dao=new UserDaoImpl();
	@Override
	public int adduser(Users users) throws SQLException, AirlineException {
		
		return dao.adduser(users);
	}
	@Override
	public boolean isvalid(Users users) throws SQLException, AirlineException {
		
		return dao.isvalid(users);
	}
	@Override
	public List<String> getScheme() throws SQLException, AirlineException {
		// TODO Auto-generated method stub
		return null;
	}

}