package com.cg.air.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.air.dto.Users;
import com.cg.air.exception.AirlineException;

public interface UserServices {

	int adduser(Users user) throws SQLException, AirlineException;

	boolean isvalid(Users user) throws SQLException, AirlineException;

	List<String> getScheme() throws SQLException, AirlineException; ;

}
