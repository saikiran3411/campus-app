package com.cg.air.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.air.exception.AirlineException;


public class DbUtil 
{


	
	
	public static Connection getConnection() throws AirlineException{
		
		
		Connection con=null;
		
		InitialContext initialContext;
	
	
		
		try {

			initialContext = new InitialContext();
			DataSource ds = (DataSource) initialContext.lookup("java:/jdbc/OracleDS");
			
				con=ds.getConnection();
		}  
				catch (SQLException e) {
				throw new AirlineException(e.getMessage());
			
			
			
		} catch (NamingException e) {
		throw new AirlineException(e.getMessage());
		}
	
	
		
		return con;
		
		
	
	}

}
