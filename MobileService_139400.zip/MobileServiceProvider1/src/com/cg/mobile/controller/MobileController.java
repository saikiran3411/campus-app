package com.cg.mobile.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.mobile.dto.Customers;
import com.cg.mobile.dto.Rental_plan;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.service.mobileService;
import com.cg.mobile.service.serviceImpl;

@WebServlet("*.do")
public class MobileController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException,
	IOException
	{
doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException,
			IOException 
	{
		mobileService service=new serviceImpl();
		String url=request.getServletPath();
		List<String> rent1=null;
		switch(url)
		{
		/****************************************
		 * Project            : MobileServiceProvider
		 * File               : MobileController.java
		 * Author Name        : Bindu dhulipalla
		 * Description        : method to get customer form
		 * Version            : 1.0
		 * Last Modified Date : 11-Dec-2017
		 * Change Description : Description about the changes implemented
		 *****************************************/
		case "/customerForm.do":
			try {
				rent1=service.getScheme();
				request.setAttribute("rent",rent1);
				RequestDispatcher rd=request.getRequestDispatcher("CustomerForm.jsp");
				rd.forward(request, response);
			} catch (MobileException e) {
				request.setAttribute("exception", e);
				RequestDispatcher dispatcher=request.getRequestDispatcher("Error.jsp");
				dispatcher.forward(request, response);
			}
			
			break;
			/****************************************
			 * Project            : MobileServiceProvider
			 * File               : MobileImpl.java
			 * Author Name        : Bindu Dhulipalla
			 * Description        : Program to display the details of customers
			 * Version            : 1.0
			 * Last Modified Date : 11-Dec-2017
			 * Change Description : Description about the changes implemented
			 *****************************************/
		case "/ShowDetails.do":
			try {
			Rental_plan rent=new Rental_plan();
			Customers cust=new Customers();
			String fName=request.getParameter("fName");
			String lName=request.getParameter("lName");
			String address=request.getParameter("address");
			String mobileNo=request.getParameter("mobileNo");
			String scheme=request.getParameter("scheme");
			rent=service.getPlan(scheme);
			cust.setMobile_No(mobileNo);
			cust.setfName(fName);
			cust.setlName(lName);
			cust.setAddress(address);
			cust.setRental_Id(scheme);
			int flag=service.addCustomer(cust);
			if(flag==1)
			{
				request.setAttribute("rent",rent);
				request.setAttribute("customer",cust);
				RequestDispatcher rd1=request.getRequestDispatcher("PlanDetails.jsp");
				rd1.forward(request, response);
			}
			
			} catch (MobileException e)
			{
				request.setAttribute("exception", e);
				RequestDispatcher dispatcher=request.getRequestDispatcher("Error.jsp");
				dispatcher.forward(request, response);
			}
			break;
				
		 
			
			
			
		}
	}

}
