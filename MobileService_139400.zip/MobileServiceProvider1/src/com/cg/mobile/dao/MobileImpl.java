package com.cg.mobile.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.mobile.dto.Customers;
import com.cg.mobile.dto.Rental_plan;
import com.cg.mobile.exception.MobileException;
import com.cg.mobile.util.DbUtil;

public class MobileImpl implements MobileDAO  
{

	@Override
	/****************************************
	 * Project            : MobileServiceProvider
	 * File               : MobileImpl.java
	 * Author Name        : Bindu Dhulipalla
	 * Description        : Program to display get scheme plan
	 * Version            : 1.0
	 * Last Modified Date : 11-Dec-2017
	 * Change Description : Description about the changes implemented
	 *****************************************/
	public Rental_plan getPlan(String scheme) throws MobileException
	{
	Rental_plan plan=new Rental_plan();
	Connection con=null;
	PreparedStatement st=null;
	try {
	
			con=DbUtil.getConnection();
			st=con.prepareStatement("select * from rental_plan where rental_id=? ");
			st.setString(1,scheme);
			ResultSet rs=st.executeQuery();
			rs.next();
			plan.setLocal_Min(rs.getInt(2));
			plan.setStd_Min(rs.getInt(3));
			plan.setSms_Count(rs.getInt(4));
			plan.setData_Mb(rs.getInt(5));
			plan.setRental_Price(rs.getFloat(6));
		
		
		
	} 
	 catch (SQLException e) {
		throw new MobileException(e.getMessage());
	}
	return plan;

	
	
		
	}

	@Override
	/****************************************
	 * Project            : MobileServiceProvider
	 * File               : MobileImpl.java
	 * Author Name        : Bindu Dhulipalla
	 * Description        : Program to display add customer details plan
	 * Version            : 1.0
	 * Last Modified Date : 11-Dec-2017
	 * Change Description : Description about the changes implemented
	 *****************************************/
	public int addCustomer(Customers cust) throws MobileException {
		Connection con=null;
		PreparedStatement st=null;
		int flag=0;
		try {
			con=DbUtil.getConnection();
			st=con.prepareStatement("insert into customers values(?,?,?,?,?)");
			st.setString(1,cust.getMobile_No());
			st.setString(2, cust.getfName());
			st.setString(3,cust.getlName());
			st.setString(4,cust.getAddress());
			st.setString(5,cust.getRental_Id());
			flag=st.executeUpdate();
		} 
		catch (SQLException e) {
			throw new MobileException(e.getMessage());
		}
		return flag;
	}

	@Override
	/****************************************
	 * Project            : MobileServiceProvider
	 * File               : MobileImpl.java
	 * Author Name        : Bindu Dhulipalla
	 * Description        : Method implementation for get scheme plan
	 * Version            : 1.0
	 * Last Modified Date : 11-Dec-2017
	 * Change Description : Description about the changes implemented
	 *****************************************/
	public List<String> getScheme() throws MobileException {
		Connection con=null;
		PreparedStatement st=null;
		List<String> rent=new ArrayList<String>();
		
		try {
			con=DbUtil.getConnection();
			st=con.prepareStatement("select rental_id from rental_plan");
			ResultSet rs=st.executeQuery();
			while(rs.next())
			{
				rent.add(rs.getString(1));
			}
		} catch (SQLException e) {
			throw new MobileException(e.getMessage());
		}
		return rent;
	}

}
