package com.cg.mobile.dto;

public class Customers
{
private String mobile_No;
private String fName;
private String lName;
private String address;
private String rental_Id;
public String getMobile_No() {
	return mobile_No;
}
public void setMobile_No(String mobile_No) {
	this.mobile_No = mobile_No;
}
public String getfName() {
	return fName;
}
public void setfName(String fName) {
	this.fName = fName;
}
public String getlName() {
	return lName;
}
public void setlName(String lName) {
	this.lName = lName;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getRental_Id() {
	return rental_Id;
}
public void setRental_Id(String rental_Id) {
	this.rental_Id = rental_Id;
}
}
