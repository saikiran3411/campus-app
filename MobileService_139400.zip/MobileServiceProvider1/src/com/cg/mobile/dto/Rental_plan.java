package com.cg.mobile.dto;

public class Rental_plan
{
private String rental_Id;
private int local_Min;
private int std_Min;
private int sms_Count;
private int data_Mb;
private float rental_Price;
public String getRental_Id() {
	return rental_Id;
}
public void setRental_Id(String rental_Id) {
	this.rental_Id = rental_Id;
}
public int getLocal_Min() {
	return local_Min;
}
public void setLocal_Min(int local_Min) {
	this.local_Min = local_Min;
}
public int getStd_Min() {
	return std_Min;
}
public void setStd_Min(int std_Min) {
	this.std_Min = std_Min;
}
public int getSms_Count() {
	return sms_Count;
}
public void setSms_Count(int sms_Count) {
	this.sms_Count = sms_Count;
}
public int getData_Mb() {
	return data_Mb;
}
public void setData_Mb(int data_Mb) {
	this.data_Mb = data_Mb;
}
public float getRental_Price() {
	return rental_Price;
}
public void setRental_Price(float rental_Price) {
	this.rental_Price = rental_Price;
}
}
