package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.dto.Customers;
import com.cg.mobile.dto.Rental_plan;
import com.cg.mobile.exception.MobileException;

public interface mobileService
{
	public Rental_plan getPlan(String scheme)throws MobileException;
	public int addCustomer(Customers cust) throws MobileException;
	public List<String> getScheme() throws MobileException;
}
