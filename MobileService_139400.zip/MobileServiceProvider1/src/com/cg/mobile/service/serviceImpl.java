package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.dao.MobileDAO;
import com.cg.mobile.dao.MobileImpl;
import com.cg.mobile.dto.Customers;
import com.cg.mobile.dto.Rental_plan;
import com.cg.mobile.exception.MobileException;

public class serviceImpl implements mobileService {

	MobileDAO mobile=new MobileImpl();
	@Override
	public Rental_plan getPlan(String scheme) throws MobileException {
		
		return mobile.getPlan(scheme);
	}
	@Override
	public int addCustomer(Customers cust) throws MobileException {
		
		return mobile.addCustomer(cust);
	}
	@Override
	public List<String> getScheme() throws MobileException {
		
		return mobile.getScheme();
	}

}
