package com.cg.mobile.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.cg.mobile.exception.MobileException;



public class DbUtil 
{
	
	public static Connection getConnection() throws MobileException
	{
		InitialContext context=null;
		DataSource ds=null;
		try {
			context=new InitialContext();
			ds=(DataSource) context.lookup("java:/jdbc/OracleDS");
			return ds.getConnection();
		} 
		catch (NamingException e) {
			
				throw new MobileException(e.getMessage());
			
		} catch (SQLException e) {
			throw new MobileException(e.getMessage());
		}
		
		
	}
}
