function  WWHBookData_Files(P)
{
P.fA("Welcome to ClaimCenter 1.11.0","cover.html");
}
