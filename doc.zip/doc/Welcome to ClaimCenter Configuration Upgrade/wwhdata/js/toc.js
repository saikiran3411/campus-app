function  WWHBookData_AddTOCEntries(P)
{
var A=P.fN("Welcome to ClaimCenter 1.11.0","0");
}
