// Copyright (c) 2001-2003 Quadralay Corporation.  All rights reserved.
//

function  WWHBookGroups_Books(ParamTop)
{


  ParamTop.fAddDirectory("Welcome%20to%20ClaimCenter%20Configuration%20Upgrade", null, null, null, null);
  ParamTop.fAddDirectory("Configuration%20Upgrade%20Guide", null, null, null, null);
}

function  WWHBookGroups_ShowBooks()
{
  return true;
}

function  WWHBookGroups_ExpandAllAtTop()
{
  return false;
}
